import React, { PropTypes } from 'react';
import { Router, Route, IndexRoute, Link } from 'dva/router';
import WXpay from './routes/wxpay';

export default function({ history }) {
  return (
    <Router history={history}>
      <Route path="/" component={WXpay} />
    </Router>
  );
};
