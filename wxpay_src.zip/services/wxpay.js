'use strict';
import request from '../utils/request';
// import { httpUrl } from '../tests/testHttpUrl';
// 
// http://localhost:8080/iwantfame
// iwantfame.91youlin.com/api
// 
export function fetchWXPay(params) {
  return request('http://iwantfame.91youlin.com/api/user/support/vote.do',{
    method: 'post',
    credentials:'include',
    headers: {
       "Content-Type": "application/x-www-form-urlencoded",
    },
    body:`recordId=${params.recordId}&voteCount=${params.voteCount}&openId=${params.openId}`,
    mode:"cors",
  });
}

export function fetchWxOauth(code){//微信登陆
  return request(`http://iwantfame.91youlin.com/api/oauth/wx_oauth.do`,{
    method: 'post',
    credentials:'include',
    headers: {
       "Content-Type": "application/x-www-form-urlencoded",
    },
    body:`code=${code}`,
    mode:"cors",
  });
}

export function refereshToken(params) {//刷新token
  return request(`http://iwantfame.91youlin.com/api/oauth/referesh_token.do`,{
    method: 'post',
    credentials:'include',
    headers: {
       "Content-Type": "application/x-www-form-urlencoded",
    },
    body:`refereshToken=${params.refereshToken}`,
    mode:"cors",
  });
}
