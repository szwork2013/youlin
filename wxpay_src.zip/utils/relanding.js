import { refereshToken } from '../services/wxpay';

export function relanding() {
	const userinfo = JSON.parse(localStorage.getItem('MY_USER_INFO'));
	var parmas = {'refereshToken':userinfo.refreshToken};
	refereshToken(parmas).then((value)=>{
		if (value.data && value.data.success) {
			userinfo.accessToken = value.data.resultObject.accessToken;
			userinfo.refreshToken = value.data.resultObject.refreshToken;
			localStorage.setItem('MY_USER_INFO',JSON.stringify(userinfo));
			document.cookie = 'JSESSIONID'+ "=" + escape(value.data.resultObject.accessToken);
		}
	}),(error)=>{

	}
}