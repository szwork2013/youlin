'use strict';

import React,{PropTypes,Component} from 'react';
import ReactDom from 'react-dom';
import styles from './wxpay.less';
import pathToRegexp from 'path-to-regexp';
import { fetchWXPay,fetchWxOauth } from '../services/wxpay';
import { relanding } from '../utils/relanding'

var tags = [10,50,100,500,1000,5000];
var recordId = '';

var config ={
    url:'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx93bec9ce3a446c79&redirect_uri=' + encodeURIComponent(location.href) + '&response_type=code&scope=snsapi_userinfo&state=123&#wechat_redirect',
    userInfo:JSON.parse(localStorage.getItem('MY_USER_INFO')),
};

class WXpay extends Component{

    constructor(props) {
        super(props);
        this.state = {
          selectId: '',
          ticketNumber:'',
        };
    }

    componentWillMount() {
        var match = location.search.match(/roleId=(\d+)/);
        if (match) {
            recordId  = match[1];
        } else {
            alert('参数错误!');
            return;
        }
        this.getUserInfo();
    }

    componentDidMount() {
        
    }

    getUserInfo(){
        if(config.userInfo){
            if (config.userInfo.userAtom) {
                if (config.userInfo.userAtom.openId) {
                    return JSON.parse(localStorage.getItem('MY_USER_INFO'));
                }
            }
        }else{
            if(this.getQueryString('code') != null){
                this.getUser(this.getQueryString('code'));
                return JSON.parse(localStorage.getItem('MY_USER_INFO'));
            }else{
                window.location.href = config.url;
            }
        }
    }

    getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");
        var r = window.location.search.substr(1).match(reg);
        if (r!=null) return unescape(r[2]); return null;
    }

    getUser(code){
        fetchWxOauth(code).then(function(value) {
            if (value.data.code !== 0) {
                alert(value.data.message);
                return;
            }

            document.cookie='JSESSIONID='+ value.data.resultObject.accessToken;
            //只保存需要的参数
            var myUserInfoStr = localStorage.getItem('MY_USER_INFO');
            var myUserInfo;
            try {
                myUserInfo = JSON.parse(myUserInfoStr) || {};
            } catch(e) {
                myUserInfo = {
                    userAtom: {}
                };
            }

            //alert(JSON.stringify(value));

            myUserInfo.refreshToken = value.data.resultObject.refreshToken;
            myUserInfo.accessToken = value.data.resultObject.accessToken;
            myUserInfo.userAtom = value.data.resultObject.userAtom;
            //myUserInfo.userAtom.username = value.data.resultObject.userAtom.username;
            //myUserInfo.userAtom.headImg = value.data.resultObject.userAtom.headImg;
            //myUserInfo.userAtom.openId = value.data.resultObject.userAtom.openId;
            localStorage.setItem('MY_USER_INFO',JSON.stringify(myUserInfo));

            config.userInfo = myUserInfo;

            //alert(JSON.stringify(myUserInfo));

            //document.cookie='JSESSIONID'+ value.data.resultObject.accessToken;
            //localStorage.setItem('MY_USER_INFO',JSON.stringify(value));
        }, function(value) {
            console.log('req error!');
        });
    }


    onSelect(number,i){
        this.setState({
            selectId:i,
            ticketNumber:number,
        })
    }

    onChangeClick(){
        var self = this;
        if (this.state.ticketNumber) {
            const userInfo = JSON.parse(localStorage.getItem('MY_USER_INFO'));
            console.log(JSON.stringify(userInfo));

            //alert(JSON.stringify(userInfo));

            const parmas={
                recordId:recordId,
                voteCount:this.state.ticketNumber,
                openId:userInfo.userAtom.openId,
            }

            //alert(JSON.stringify(parmas));

            fetchWXPay(parmas).then(function(requestData) {
                //alert(JSON.stringify(requestData));
                if (requestData.data) {
                    if (requestData.data.success) {
                        const reqdata = requestData.data.resultObject;
                        //alert(JSON.stringify(reqdata));

                        WeixinJSBridge.invoke(
                               'getBrandWCPayRequest', {
                                   "appId" :reqdata.appId,     //公众号名称，由商户传入     
                                   "timeStamp":reqdata.timeStamp,         //时间戳，自1970年以来的秒数     
                                   "nonceStr":reqdata.nonceStr, //随机串     
                                   "package":reqdata.package,     
                                   "signType":"MD5",         //微信签名方式：     
                                   "paySign":reqdata.paySign//微信签名 
                               },
                               function(res){     
                                  if(res.err_msg == "get_brand_wcpay_request:ok" ) {
                                    _self.checkPaySuccess(data.outTradeNo);
                                    } else if( res.err_msg == "get_brand_wcpay_request:cancel" ){
                                        global.win_warning("支付已取消");
                                    }
                                }    // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。 
                        )
                    }else{
                        if (requestData.data.code === -10) {
                            alert(requestData.data.message + ', 请重试');
                            relanding();
                            //console.log(requestData.data.message);
                        }

                        if (requestData.data.code === -1) {
                            alert(requestData.data.message);
                            config.userInfo = null;
                            //localStorage.setItem('MY_USER_INFO', '{}');
                            self.getUserInfo();
                            //console.log(requestData.data.message);
                        }
                    }
                }
            }, function(value) {
                alert('req error!');
            });

        }else{
            alert('请选择要投票的数量！');
        }
    }

    onCancel() {
        window.location.href = '/';
    }

    render(){

        return (
            <div className={styles.recharge}>
                <div className={styles.wxBox}>
                    <div className={styles.wx}></div>
                    <span>微信支付</span>
                </div>
                <p>
                    <span>充值数量</span>
                    1角=1票
                </p>
                <div className={styles.ticket}>
                {
                    tags.map((ticket,i)=> {
                        return<div key={i} onClick={()=>this.onSelect(ticket,i)} className={styles.ticketBox}><div><p>{ticket}票</p><p>¥{ticket/10}</p></div></div>
                    })
                }
                </div>
                <button className={styles.btn} onClick={()=>this.onChangeClick()}>立即投票</button>
                <button className={styles.btn} onClick={()=>this.onCancel()}>取消</button>
            </div>
        );
    }
};

WXpay.propTypes = {
};

export default WXpay;
